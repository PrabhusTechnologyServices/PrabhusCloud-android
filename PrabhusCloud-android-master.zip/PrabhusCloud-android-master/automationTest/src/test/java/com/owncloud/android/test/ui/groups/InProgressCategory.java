package com.owncloud.android.test.ui.groups;

public interface InProgressCategory extends IgnoreTestCategory{

}
