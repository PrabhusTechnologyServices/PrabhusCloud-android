### Actual behaviour
-Tell us what happens

### Expected behaviour
-Tell us what should happen
 
### Steps to reproduce
1. 
2. 
3. 


### Environment data
Android version:

Device model: 

Stock or customized system:

Nextcloud app version:

Nextcloud server version:

### Logs
#### Web server error log
```
Insert your webserver log here
```

#### Nextcloud log (data/nextcloud.log)
```
Insert your Nextcloud log here
```
